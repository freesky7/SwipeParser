package com.swipeparser;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JProgressBar;

public class ParserUI {

	private JFrame frmSwipeparser;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ParserUI window = new ParserUI();
					window.frmSwipeparser.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ParserUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSwipeparser = new JFrame();
		frmSwipeparser.setFont(new Font("Dialog", Font.PLAIN, 14));
		frmSwipeparser.setTitle("SwipeParser");
		frmSwipeparser.setBounds(100, 100, 450, 300);
		frmSwipeparser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSwipeparser.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(151, 58, 293, 26);
		frmSwipeparser.getContentPane().add(textField);
		textField.setColumns(10);
		final JFileChooser fc = new JFileChooser();
		JButton btnParseFile = new JButton("Parse File");
		btnParseFile.setEnabled(false);
		
		JButton btnChooseFile = new JButton("Choose File");
		btnChooseFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int returnVal = fc.showOpenDialog(frmSwipeparser);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					textField.setText(fc.getSelectedFile().getAbsolutePath());
					btnParseFile.setEnabled(true);
				}
			}
		});
		btnChooseFile.setBounds(22, 58, 117, 29);
		frmSwipeparser.getContentPane().add(btnChooseFile);

		btnParseFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Parser parser = new Parser();
				parser.parse(fc.getSelectedFile());
			}
		});
		btnParseFile.setBounds(22, 99, 117, 29);
		frmSwipeparser.getContentPane().add(btnParseFile);
		
		
		
		
		JLabel lblResult = new JLabel("");
		lblResult.setBounds(32, 140, 412, 77);
		frmSwipeparser.getContentPane().add(lblResult);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(151, 99, 293, 29);
		frmSwipeparser.getContentPane().add(progressBar);
		
		JLabel lblWelcome = new JLabel("Hello, welcome to SwipeParser.\nPlease select a file to start...");
		lblWelcome.setBounds(29, 6, 415, 29);
		frmSwipeparser.getContentPane().add(lblWelcome);
	}
}
